// Alternar telas
function mostrarTela(id) {
  document.querySelectorAll(".tela").forEach(sec => sec.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}

// Handlers que chamam suas funções originais

function handleCadastrar() {
  const titulo = document.getElementById("titulo").value;
  const autor = document.getElementById("autor").value;
  const preco = parseFloat(document.getElementById("preco").value);
  cadastrarLivros({ titulo, autor, preco });
  alert("Livro cadastrado!");
}

function handleListar() {
  const lista = listarLivros();
  document.getElementById("lista").innerHTML =
    lista.map(l => `<p>${l.titulo} - ${l.autor} - R$${l.preco}</p>`).join("");
}

function handleExcluir() {
  const titulo = document.getElementById("tituloExcluir").value;
  excluirLivros(titulo);
  alert("Livro excluído (se existia).");
}

function handleTotal() {
  const total = calcularTotal();
  document.getElementById("resultadoTotal").textContent = `R$ ${total}`;
}

function handleRelatorio() {
  const rel = gerarRelatorio();
  document.getElementById("relatorioTexto").textContent = rel;
}
